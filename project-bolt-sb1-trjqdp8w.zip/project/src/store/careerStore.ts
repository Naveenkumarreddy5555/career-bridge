import { create } from 'zustand';

export interface CareerPath {
  id: string;
  title: string;
  category: string;
  description: string;
  requirements: string[];
  skills: string[];
  salary: {
    entry: string;
    mid: string;
    senior: string;
  };
  growth: string;
  roadmap: {
    education: string[];
    certifications: string[];
    experience: string[];
    milestones: { title: string; description: string }[];
  };
  resources: {
    courses: { title: string; url: string }[];
    books: { title: string; author: string }[];
    websites: { title: string; url: string }[];
  };
}

interface CareerState {
  careers: CareerPath[];
  savedCareers: string[];
  loading: boolean;
  fetchCareers: () => Promise<void>;
  saveCareer: (careerId: string) => void;
  unsaveCareer: (careerId: string) => void;
}

// Mock data
const mockCareers: CareerPath[] = [
  {
    id: "software-engineer",
    title: "Software Engineer",
    category: "Computer Science",
    description: "Software engineers design, develop, and maintain software systems and applications using programming languages, frameworks, and software development methodologies.",
    requirements: [
      "Bachelor's degree in Computer Science or related field",
      "Strong problem-solving abilities",
      "Knowledge of data structures and algorithms",
      "Proficiency in programming languages"
    ],
    skills: [
      "JavaScript/TypeScript",
      "React/Angular/Vue",
      "Node.js",
      "Python",
      "Database management",
      "Git version control",
      "CI/CD pipelines"
    ],
    salary: {
      entry: "$70,000 - $90,000",
      mid: "$90,000 - $130,000",
      senior: "$130,000 - $180,000+"
    },
    growth: "Faster than average (22% growth through 2030)",
    roadmap: {
      education: [
        "Bachelor's in Computer Science or related field",
        "Consider Master's for specialization or advancement"
      ],
      certifications: [
        "AWS Certified Developer",
        "Microsoft Certified: Azure Developer Associate",
        "Google Cloud Professional Developer"
      ],
      experience: [
        "Internship or entry-level development position",
        "Junior developer (1-3 years)",
        "Mid-level developer (3-5 years)",
        "Senior developer (5+ years)"
      ],
      milestones: [
        {
          title: "First Major Project",
          description: "Complete a significant project from requirements to deployment"
        },
        {
          title: "Code Review Leadership",
          description: "Regularly lead code reviews and mentor junior developers"
        },
        {
          title: "Architecture Design",
          description: "Lead the architecture design of a complex system"
        }
      ]
    },
    resources: {
      courses: [
        {
          title: "CS50: Introduction to Computer Science",
          url: "https://www.edx.org/course/introduction-computer-science-harvardx-cs50x"
        },
        {
          title: "The Complete Web Developer Course",
          url: "https://www.udemy.com/course/the-complete-web-developer-course-2/"
        }
      ],
      books: [
        {
          title: "Clean Code",
          author: "Robert C. Martin"
        },
        {
          title: "Design Patterns",
          author: "Erich Gamma et al."
        }
      ],
      websites: [
        {
          title: "GitHub",
          url: "https://github.com"
        },
        {
          title: "Stack Overflow",
          url: "https://stackoverflow.com"
        }
      ]
    }
  },
  {
    id: "data-scientist",
    title: "Data Scientist",
    category: "Data Science",
    description: "Data scientists analyze complex data to help organizations make better decisions. They use statistics, machine learning, and programming to extract insights from data.",
    requirements: [
      "Master's or PhD in Data Science, Statistics, or related field",
      "Strong mathematical and statistical knowledge",
      "Programming skills",
      "Experience with data visualization"
    ],
    skills: [
      "Python",
      "R",
      "SQL",
      "Machine Learning",
      "TensorFlow/PyTorch",
      "Data Visualization",
      "Big Data Tools"
    ],
    salary: {
      entry: "$85,000 - $110,000",
      mid: "$110,000 - $140,000",
      senior: "$140,000 - $200,000+"
    },
    growth: "Much faster than average (31% growth through 2030)",
    roadmap: {
      education: [
        "Bachelor's in Statistics, Math, Computer Science, or related field",
        "Master's or PhD in Data Science or related field"
      ],
      certifications: [
        "IBM Data Science Professional Certificate",
        "Microsoft Certified: Azure Data Scientist Associate",
        "Google Professional Data Engineer"
      ],
      experience: [
        "Data Analyst role",
        "Junior Data Scientist (1-3 years)",
        "Mid-level Data Scientist (3-6 years)",
        "Senior Data Scientist (6+ years)"
      ],
      milestones: [
        {
          title: "First Predictive Model",
          description: "Deploy a predictive model that drives business decisions"
        },
        {
          title: "Advanced Algorithm Design",
          description: "Design and implement complex algorithms to solve difficult problems"
        },
        {
          title: "Team Leadership",
          description: "Lead a team of data scientists on a major project"
        }
      ]
    },
    resources: {
      courses: [
        {
          title: "Data Science: Machine Learning",
          url: "https://www.edx.org/professional-certificate/harvardx-data-science"
        },
        {
          title: "Deep Learning Specialization",
          url: "https://www.coursera.org/specializations/deep-learning"
        }
      ],
      books: [
        {
          title: "Hands-On Machine Learning with Scikit-Learn and TensorFlow",
          author: "Aurélien Géron"
        },
        {
          title: "Python for Data Analysis",
          author: "Wes McKinney"
        }
      ],
      websites: [
        {
          title: "Kaggle",
          url: "https://www.kaggle.com"
        },
        {
          title: "Towards Data Science",
          url: "https://towardsdatascience.com"
        }
      ]
    }
  },
  {
    id: "ux-designer",
    title: "UX Designer",
    category: "Design",
    description: "UX designers research, design, and optimize user experiences for products and services, focusing on usability, accessibility, and user satisfaction.",
    requirements: [
      "Bachelor's degree in Design, HCI, or related field",
      "Strong portfolio showcasing UX work",
      "Research and analytical skills",
      "Proficiency in design tools"
    ],
    skills: [
      "User Research",
      "Wireframing & Prototyping",
      "Figma/Sketch/Adobe XD",
      "Information Architecture",
      "Usability Testing",
      "Interaction Design",
      "Basic HTML/CSS"
    ],
    salary: {
      entry: "$65,000 - $85,000",
      mid: "$85,000 - $115,000",
      senior: "$115,000 - $160,000+"
    },
    growth: "Faster than average (13% growth through 2030)",
    roadmap: {
      education: [
        "Bachelor's in Design, Human-Computer Interaction, or related field",
        "Consider UX-specific programs or bootcamps"
      ],
      certifications: [
        "Google UX Design Professional Certificate",
        "Nielsen Norman Group UX Certification",
        "Interaction Design Foundation Courses"
      ],
      experience: [
        "UX Design Internship",
        "Junior UX Designer (1-2 years)",
        "Mid-level UX Designer (2-5 years)",
        "Senior UX Designer (5+ years)"
      ],
      milestones: [
        {
          title: "First End-to-End Project",
          description: "Complete a full UX project from research to implementation"
        },
        {
          title: "Measurable Impact",
          description: "Achieve measurable improvements in user metrics through design"
        },
        {
          title: "Design System Creation",
          description: "Lead the creation or significant update of a design system"
        }
      ]
    },
    resources: {
      courses: [
        {
          title: "Google UX Design Professional Certificate",
          url: "https://www.coursera.org/professional-certificates/google-ux-design"
        },
        {
          title: "Interaction Design Foundation Courses",
          url: "https://www.interaction-design.org/courses"
        }
      ],
      books: [
        {
          title: "Don't Make Me Think",
          author: "Steve Krug"
        },
        {
          title: "The Design of Everyday Things",
          author: "Don Norman"
        }
      ],
      websites: [
        {
          title: "Nielsen Norman Group",
          url: "https://www.nngroup.com"
        },
        {
          title: "UX Collective",
          url: "https://uxdesign.cc"
        }
      ]
    }
  }
];

export const useCareerStore = create<CareerState>((set) => ({
  careers: [],
  savedCareers: [],
  loading: false,
  fetchCareers: async () => {
    set({ loading: true });
    
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000));
    
    set({ careers: mockCareers, loading: false });
  },
  saveCareer: (careerId) => {
    set((state) => ({
      savedCareers: [...state.savedCareers, careerId]
    }));
  },
  unsaveCareer: (careerId) => {
    set((state) => ({
      savedCareers: state.savedCareers.filter(id => id !== careerId)
    }));
  }
}));