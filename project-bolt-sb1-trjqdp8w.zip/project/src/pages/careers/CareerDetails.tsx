import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Briefcase, TrendingUp, Star, GraduationCap, Award, MapPin, Clock, BookOpen, Bookmark, BookmarkCheck } from 'lucide-react';
import { useCareerStore, CareerPath } from '../../store/careerStore';
import Button from '../../components/ui/Button';
import Card, { CardHeader, CardTitle, CardContent } from '../../components/ui/Card';

const CareerDetails = () => {
  const { id } = useParams<{ id: string }>();
  const { careers, savedCareers, fetchCareers, saveCareer, unsaveCareer } = useCareerStore();
  const [activeTab, setActiveTab] = useState('roadmap');
  
  useEffect(() => {
    if (careers.length === 0) {
      fetchCareers();
    }
  }, [careers.length, fetchCareers]);
  
  const career = careers.find(c => c.id === id);
  const isSaved = savedCareers.includes(id || '');
  
  const handleToggleSave = () => {
    if (!id) return;
    
    if (isSaved) {
      unsaveCareer(id);
    } else {
      saveCareer(id);
    }
  };
  
  if (!career) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12 flex flex-col items-center justify-center min-h-[50vh]">
        <Briefcase className="h-16 w-16 text-gray-300 dark:text-gray-600 mb-4" />
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Career not found</h2>
        <p className="text-gray-600 dark:text-gray-300 mb-6">
          The career path you are looking for doesn't exist or has been removed.
        </p>
        <Link to="/careers">
          <Button>
            <ArrowLeft size={16} className="mr-2" />
            Back to Careers
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Back button */}
      <div className="mb-6">
        <Link to="/careers" className="inline-flex items-center text-gray-600 dark:text-gray-300 hover:text-indigo-600 dark:hover:text-indigo-400">
          <ArrowLeft size={16} className="mr-2" />
          Back to All Careers
        </Link>
      </div>
      
      {/* Career header */}
      <motion.div 
        className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8 mb-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center mb-2">
              <span className="inline-block bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 text-sm px-2 py-1 rounded mr-2">
                {career.category}
              </span>
              <span className="inline-block bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 text-sm px-2 py-1 rounded">
                {career.growth}
              </span>
            </div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">{career.title}</h1>
            <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-3xl">
              {career.description}
            </p>
            <div className="flex flex-wrap gap-6">
              <div className="flex items-center">
                <Briefcase className="h-5 w-5 text-gray-500 dark:text-gray-400 mr-2" />
                <div>
                  <span className="block text-sm text-gray-500 dark:text-gray-400">Entry Salary</span>
                  <span className="font-medium text-gray-900 dark:text-white">{career.salary.entry}</span>
                </div>
              </div>
              <div className="flex items-center">
                <TrendingUp className="h-5 w-5 text-gray-500 dark:text-gray-400 mr-2" />
                <div>
                  <span className="block text-sm text-gray-500 dark:text-gray-400">Senior Salary</span>
                  <span className="font-medium text-gray-900 dark:text-white">{career.salary.senior}</span>
                </div>
              </div>
            </div>
          </div>
          <div>
            <Button
              onClick={handleToggleSave}
              variant={isSaved ? 'primary' : 'outline'}
              className="flex items-center gap-2"
            >
              {isSaved ? (
                <>
                  <BookmarkCheck size={18} />
                  Saved
                </>
              ) : (
                <>
                  <Bookmark size={18} />
                  Save Career
                </>
              )}
            </Button>
          </div>
        </div>
      </motion.div>
      
      {/* Tabs */}
      <div className="mb-8 border-b border-gray-200 dark:border-gray-700">
        <nav className="flex space-x-8">
          {['roadmap', 'skills', 'resources'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap ${
                activeTab === tab
                  ? 'border-indigo-500 text-indigo-600 dark:border-indigo-400 dark:text-indigo-400'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300 dark:hover:border-gray-600'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </nav>
      </div>
      
      {/* Tab content */}
      <div className="mb-12">
        {activeTab === 'roadmap' && (
          <RoadmapTab career={career} />
        )}
        
        {activeTab === 'skills' && (
          <SkillsTab career={career} />
        )}
        
        {activeTab === 'resources' && (
          <ResourcesTab career={career} />
        )}
      </div>
    </div>
  );
};

const RoadmapTab = ({ career }: { career: CareerPath }) => {
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <GraduationCap className="h-5 w-5 mr-2" />
              Education Path
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              {career.roadmap.education.map((item, index) => (
                <li key={index} className="flex">
                  <div className="flex-shrink-0 flex items-center mr-4">
                    <div className="h-10 w-10 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center text-indigo-600 dark:text-indigo-400 font-semibold">
                      {index + 1}
                    </div>
                    {index < career.roadmap.education.length - 1 && (
                      <div className="absolute h-full w-0.5 bg-indigo-100 dark:bg-indigo-900/30 ml-5 mt-10"></div>
                    )}
                  </div>
                  <div className="pt-2">
                    <p className="font-medium text-gray-900 dark:text-white">{item}</p>
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Award className="h-5 w-5 mr-2" />
              Certifications
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              {career.roadmap.certifications.map((cert, index) => (
                <li key={index} className="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <div className="flex items-start">
                    <div className="h-6 w-6 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center text-indigo-600 dark:text-indigo-400 text-xs font-semibold mt-0.5 mr-3">
                      {index + 1}
                    </div>
                    <p className="font-medium text-gray-900 dark:text-white">{cert}</p>
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
      
      {/* Career journey visualization */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <MapPin className="h-5 w-5 mr-2" />
            Career Journey
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative py-8">
            {/* Timeline line */}
            <div className="absolute left-8 top-0 bottom-0 w-1 bg-indigo-100 dark:bg-indigo-900/30 rounded"></div>
            
            {/* Timeline events */}
            <div className="space-y-12">
              {career.roadmap.experience.map((phase, index) => (
                <div key={index} className="relative flex items-start">
                  <div className="absolute left-8 w-3 h-3 bg-indigo-500 border-4 border-indigo-100 dark:border-indigo-900/50 rounded-full -translate-x-1/2 mt-1.5"></div>
                  <div className="ml-16">
                    <div className="bg-white dark:bg-gray-700 shadow-sm rounded-lg p-4 relative">
                      {/* Triangle pointing to timeline */}
                      <div className="absolute w-3 h-3 bg-white dark:bg-gray-700 transform rotate-45 -left-1.5 top-4"></div>
                      <h3 className="font-medium text-gray-900 dark:text-white text-lg mb-2">{phase}</h3>
                      {index < career.roadmap.milestones.length && (
                        <div className="mt-2 pt-3 border-t border-gray-100 dark:border-gray-600">
                          <h4 className="text-sm font-medium text-indigo-600 dark:text-indigo-400 mb-1">
                            Key Milestone:
                          </h4>
                          <p className="text-gray-600 dark:text-gray-300 text-sm font-medium">
                            {career.roadmap.milestones[index].title}
                          </p>
                          <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
                            {career.roadmap.milestones[index].description}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

const SkillsTab = ({ career }: { career: CareerPath }) => {
  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>Required Skills</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {career.skills.map((skill, index) => (
              <div 
                key={index} 
                className="flex items-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg"
              >
                <div className="h-8 w-8 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center mr-3">
                  <CheckCircleIcon className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
                </div>
                <span className="font-medium text-gray-800 dark:text-gray-200">{skill}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Requirements</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3">
            {career.requirements.map((req, index) => (
              <li key={index} className="flex items-start">
                <div className="h-6 w-6 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center text-indigo-600 dark:text-indigo-400 text-xs font-semibold mt-0.5 mr-3">
                  {index + 1}
                </div>
                <p className="text-gray-700 dark:text-gray-300">{req}</p>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="h-5 w-5 mr-2" />
            Salary Progression
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <SalaryCard level="Entry Level" salary={career.salary.entry} color="bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400" />
              <SalaryCard level="Mid-Level" salary={career.salary.mid} color="bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400" />
              <SalaryCard level="Senior Level" salary={career.salary.senior} color="bg-sky-100 dark:bg-sky-900/30 text-sky-600 dark:text-sky-400" />
            </div>
            
            <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <div className="flex items-start">
                <Clock className="h-5 w-5 text-gray-500 dark:text-gray-400 mt-0.5 mr-3" />
                <div>
                  <h4 className="font-medium text-gray-900 dark:text-white mb-1">Future Growth Prospects</h4>
                  <p className="text-gray-700 dark:text-gray-300">{career.growth}</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

const ResourcesTab = ({ career }: { career: CareerPath }) => {
  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BookOpen className="h-5 w-5 mr-2" />
            Recommended Courses
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {career.resources.courses.map((course, index) => (
              <a 
                key={index} 
                href={course.url} 
                target="_blank" 
                rel="noopener noreferrer"
                className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                <h3 className="font-medium text-indigo-600 dark:text-indigo-400 mb-1">{course.title}</h3>
                <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                  <ExternalLinkIcon className="h-4 w-4 mr-1" />
                  Visit Course
                </div>
              </a>
            ))}
          </div>
        </CardContent>
      </Card>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Recommended Books</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              {career.resources.books.map((book, index) => (
                <li key={index} className="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <p className="font-medium text-gray-900 dark:text-white">{book.title}</p>
                  <p className="text-gray-500 dark:text-gray-400 text-sm">by {book.author}</p>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Useful Websites</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              {career.resources.websites.map((website, index) => (
                <li key={index}>
                  <a 
                    href={website.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                  >
                    <GlobeIcon className="h-5 w-5 text-indigo-500 dark:text-indigo-400 mr-3" />
                    <span className="font-medium text-gray-900 dark:text-white">{website.title}</span>
                    <ExternalLinkIcon className="h-4 w-4 text-gray-400 ml-auto" />
                  </a>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

const SalaryCard = ({ level, salary, color }: { level: string; salary: string; color: string }) => (
  <div className="p-4 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-sm">
    <div className={`inline-block px-2 py-1 rounded text-xs font-medium mb-2 ${color}`}>
      {level}
    </div>
    <p className="text-xl font-bold text-gray-900 dark:text-white">{salary}</p>
  </div>
);

// Simple icon components
const CheckCircleIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="10" />
    <path d="m9 12 2 2 4-4" />
  </svg>
);

const ExternalLinkIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
    <polyline points="15 3 21 3 21 9" />
    <line x1="10" y1="14" x2="21" y2="3" />
  </svg>
);

const GlobeIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="12" r="10" />
    <line x1="2" y1="12" x2="22" y2="12" />
    <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
  </svg>
);

export default CareerDetails;