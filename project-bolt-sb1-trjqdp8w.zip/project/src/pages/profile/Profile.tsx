import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuthStore } from '../../store/authStore';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import { CheckCircle } from 'lucide-react';

interface ProfileForm {
  education: string;
  skills: string[];
  interests: string[];
  goalCareer: string;
}

const skillOptions = [
  'Communication', 'Problem Solving', 'Critical Thinking', 'Leadership', 
  'Teamwork', 'Time Management', 'Adaptability', 'Programming', 
  'Data Analysis', 'Design', 'Writing', 'Public Speaking'
];

const interestOptions = [
  'Technology', 'Business', 'Healthcare', 'Education', 'Engineering',
  'Arts', 'Science', 'Environment', 'Government', 'Media',
  'Finance', 'Law', 'Construction', 'Hospitality'
];

const careerGoalOptions = [
  'Software Development', 'Data Science', 'UX/UI Design', 'Product Management',
  'Business Analysis', 'Marketing', 'Finance', 'Human Resources',
  'Healthcare', 'Education', 'Research', 'Engineering'
];

const educationLevelOptions = [
  'High School', 'Some College', 'Associate Degree',
  'Bachelor\'s Degree', 'Master\'s Degree', 'PhD'
];

const Profile = () => {
  const { user, updateUser } = useAuthStore();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState<ProfileForm>({
    education: '',
    skills: [],
    interests: [],
    goalCareer: '',
  });
  
  const [step, setStep] = useState(1);
  const totalSteps = 4;
  
  const handleEducationChange = (education: string) => {
    setFormData({ ...formData, education });
  };
  
  const toggleSkill = (skill: string) => {
    if (formData.skills.includes(skill)) {
      setFormData({
        ...formData,
        skills: formData.skills.filter(s => s !== skill)
      });
    } else {
      setFormData({
        ...formData,
        skills: [...formData.skills, skill]
      });
    }
  };
  
  const toggleInterest = (interest: string) => {
    if (formData.interests.includes(interest)) {
      setFormData({
        ...formData,
        interests: formData.interests.filter(i => i !== interest)
      });
    } else {
      setFormData({
        ...formData,
        interests: [...formData.interests, interest]
      });
    }
  };
  
  const handleCareerGoalChange = (goalCareer: string) => {
    setFormData({ ...formData, goalCareer });
  };

  const nextStep = () => {
    if (step < totalSteps) {
      setStep(step + 1);
    }
  };

  const prevStep = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real app, this would save to a backend
    updateUser({ profileCompleted: true });
    
    // Redirect to dashboard
    navigate('/dashboard');
  };
  
  const renderStepContent = () => {
    switch (step) {
      case 1:
        return (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">What is your education level?</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Select your highest level of education completed or in progress.
            </p>
            
            <div className="space-y-3">
              {educationLevelOptions.map((option) => (
                <div 
                  key={option}
                  className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                    formData.education === option 
                      ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20' 
                      : 'border-gray-200 dark:border-gray-700 hover:border-indigo-300 dark:hover:border-indigo-700'
                  }`}
                  onClick={() => handleEducationChange(option)}
                >
                  <div className="flex items-center">
                    <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                      formData.education === option 
                        ? 'border-indigo-500 bg-indigo-500' 
                        : 'border-gray-300 dark:border-gray-600'
                    }`}>
                      {formData.education === option && (
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                      )}
                    </div>
                    <span className={`ml-3 ${
                      formData.education === option 
                        ? 'text-indigo-700 dark:text-indigo-400 font-medium' 
                        : 'text-gray-700 dark:text-gray-300'
                    }`}>
                      {option}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        );
        
      case 2:
        return (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">What skills do you have?</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Select all the skills that apply to you. These will help us customize your career recommendations.
            </p>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {skillOptions.map((skill) => (
                <div 
                  key={skill}
                  className={`p-3 border rounded-lg cursor-pointer text-sm transition-colors ${
                    formData.skills.includes(skill) 
                      ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-400' 
                      : 'border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-indigo-300 dark:hover:border-indigo-700'
                  }`}
                  onClick={() => toggleSkill(skill)}
                >
                  <div className="flex items-center">
                    {formData.skills.includes(skill) && (
                      <CheckCircle size={16} className="mr-2 text-indigo-600 dark:text-indigo-400" />
                    )}
                    <span className={formData.skills.includes(skill) ? 'font-medium' : ''}>
                      {skill}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        );
        
      case 3:
        return (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">What are your interests?</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Select areas that interest you professionally. This helps us understand your passions.
            </p>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {interestOptions.map((interest) => (
                <div 
                  key={interest}
                  className={`p-3 border rounded-lg cursor-pointer text-sm transition-colors ${
                    formData.interests.includes(interest) 
                      ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-400' 
                      : 'border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-indigo-300 dark:hover:border-indigo-700'
                  }`}
                  onClick={() => toggleInterest(interest)}
                >
                  <div className="flex items-center">
                    {formData.interests.includes(interest) && (
                      <CheckCircle size={16} className="mr-2 text-indigo-600 dark:text-indigo-400" />
                    )}
                    <span className={formData.interests.includes(interest) ? 'font-medium' : ''}>
                      {interest}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        );
        
      case 4:
        return (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">What is your career goal?</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Select the career field you're most interested in pursuing.
            </p>
            
            <div className="space-y-3">
              {careerGoalOptions.map((career) => (
                <div 
                  key={career}
                  className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                    formData.goalCareer === career 
                      ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20' 
                      : 'border-gray-200 dark:border-gray-700 hover:border-indigo-300 dark:hover:border-indigo-700'
                  }`}
                  onClick={() => handleCareerGoalChange(career)}
                >
                  <div className="flex items-center">
                    <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                      formData.goalCareer === career 
                        ? 'border-indigo-500 bg-indigo-500' 
                        : 'border-gray-300 dark:border-gray-600'
                    }`}>
                      {formData.goalCareer === career && (
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                      )}
                    </div>
                    <span className={`ml-3 ${
                      formData.goalCareer === career 
                        ? 'text-indigo-700 dark:text-indigo-400 font-medium' 
                        : 'text-gray-700 dark:text-gray-300'
                    }`}>
                      {career}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        );
        
      default:
        return null;
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8">
        <div className="mb-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white">Complete Your Profile</h2>
          <p className="mt-2 text-gray-600 dark:text-gray-300">
            Help us personalize your career recommendations
          </p>
        </div>
        
        {/* Progress bar */}
        <div className="mb-8">
          <div className="flex justify-between mb-2">
            {Array.from({ length: totalSteps }).map((_, index) => (
              <div 
                key={index}
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  index + 1 === step
                    ? 'bg-indigo-600 text-white'
                    : index + 1 < step
                      ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/50 dark:text-indigo-300'
                      : 'bg-gray-100 text-gray-500 dark:bg-gray-700 dark:text-gray-400'
                }`}
              >
                {index + 1}
              </div>
            ))}
          </div>
          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
            <div 
              className="bg-indigo-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(step / totalSteps) * 100}%` }}
            ></div>
          </div>
        </div>
        
        <form onSubmit={handleSubmit}>
          <div className="min-h-[320px]">
            {renderStepContent()}
          </div>
          
          <div className="mt-8 flex justify-between">
            <Button
              type="button"
              variant="outline"
              onClick={prevStep}
              disabled={step === 1}
            >
              Previous
            </Button>
            
            {step < totalSteps ? (
              <Button
                type="button"
                onClick={nextStep}
                disabled={
                  (step === 1 && !formData.education) ||
                  (step === 2 && formData.skills.length === 0) ||
                  (step === 3 && formData.interests.length === 0)
                }
              >
                Next
              </Button>
            ) : (
              <Button
                type="submit"
                disabled={!formData.goalCareer}
              >
                Complete Profile
              </Button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};

export default Profile;