import { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, BookOpen, Video, MessageSquare, Award, ExternalLink } from 'lucide-react';
import Card, { CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/Card';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';

const resourceCategories = [
  'All',
  'Online Courses',
  'Books',
  'Communities',
  'Tools',
  'Certificates'
];

interface Resource {
  id: string;
  title: string;
  description: string;
  category: string;
  url: string;
  image: string;
  tags: string[];
}

const resourcesData: Resource[] = [
  {
    id: '1',
    title: 'Coursera',
    description: 'Access thousands of courses from top universities and organizations worldwide.',
    category: 'Online Courses',
    url: 'https://www.coursera.org/',
    image: 'https://images.pexels.com/photos/3787752/pexels-photo-3787752.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tags: ['Courses', 'Certificates', 'Skills']
  },
  {
    id: '2',
    title: 'edX',
    description: 'High-quality courses from Harvard, MIT, and more leading institutions.',
    category: 'Online Courses',
    url: 'https://www.edx.org/',
    image: 'https://images.pexels.com/photos/3769021/pexels-photo-3769021.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tags: ['Courses', 'Degrees', 'Programs']
  },
  {
    id: '3',
    title: 'Stack Overflow',
    description: 'Community for developers to learn, share knowledge, and build careers.',
    category: 'Communities',
    url: 'https://stackoverflow.com/',
    image: 'https://images.pexels.com/photos/270360/pexels-photo-270360.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tags: ['Coding', 'Q&A', 'Community']
  },
  {
    id: '4',
    title: 'LinkedIn Learning',
    description: 'Courses taught by industry experts in software, creative, and business skills.',
    category: 'Online Courses',
    url: 'https://www.linkedin.com/learning/',
    image: 'https://images.pexels.com/photos/6203495/pexels-photo-6203495.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tags: ['Professional', 'Business', 'Technology']
  },
  {
    id: '5',
    title: 'AWS Certifications',
    description: 'Validate technical skills and cloud expertise to grow your career.',
    category: 'Certificates',
    url: 'https://aws.amazon.com/certification/',
    image: 'https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tags: ['Cloud', 'IT', 'Technical']
  },
  {
    id: '6',
    title: 'GitHub',
    description: 'Platform for developers to collaborate on projects and showcase their work.',
    category: 'Tools',
    url: 'https://github.com/',
    image: 'https://images.pexels.com/photos/11035544/pexels-photo-11035544.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tags: ['Coding', 'Portfolio', 'Collaboration']
  },
  {
    id: '7',
    title: 'Atomic Habits',
    description: 'James Clear\'s guide to building good habits and breaking bad ones.',
    category: 'Books',
    url: 'https://jamesclear.com/atomic-habits',
    image: 'https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tags: ['Self-improvement', 'Productivity', 'Psychology']
  },
  {
    id: '8',
    title: 'Khan Academy',
    description: 'Free educational content covering math, science, and more.',
    category: 'Online Courses',
    url: 'https://www.khanacademy.org/',
    image: 'https://images.pexels.com/photos/256541/pexels-photo-256541.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tags: ['Free', 'Education', 'Learning']
  },
  {
    id: '9',
    title: 'Notion',
    description: 'All-in-one workspace for notes, tasks, wikis, and databases.',
    category: 'Tools',
    url: 'https://www.notion.so/',
    image: 'https://images.pexels.com/photos/6408285/pexels-photo-6408285.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tags: ['Productivity', 'Organization', 'Workspace']
  }
];

const Resources = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  
  const filteredResources = resourcesData.filter(resource => {
    const matchesSearch = 
      resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      resource.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      resource.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesCategory = selectedCategory === 'All' || resource.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });
  
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Online Courses':
        return <Video className="h-5 w-5 text-sky-500" />;
      case 'Books':
        return <BookOpen className="h-5 w-5 text-purple-500" />;
      case 'Communities':
        return <MessageSquare className="h-5 w-5 text-green-500" />;
      case 'Tools':
        return <ExternalLink className="h-5 w-5 text-rose-500" />;
      case 'Certificates':
        return <Award className="h-5 w-5 text-amber-500" />;
      default:
        return <BookOpen className="h-5 w-5 text-indigo-500" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <motion.div 
        className="text-center mb-12"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
          Learning Resources
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
          Discover curated resources to help you excel in your chosen career path
        </p>
      </motion.div>
      
      {/* Search and filter */}
      <div className="mb-12 bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <Input
              type="text"
              placeholder="Search resources..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <div className="flex overflow-x-auto pb-2 md:pb-0 hide-scrollbar">
            {resourceCategories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap mr-2 ${
                  selectedCategory === category
                    ? 'bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>
      
      {/* Resources grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredResources.map((resource, index) => (
          <ResourceCard key={resource.id} resource={resource} index={index} getCategoryIcon={getCategoryIcon} />
        ))}
      </div>
      
      {filteredResources.length === 0 && (
        <div className="text-center py-20 bg-white dark:bg-gray-800 rounded-xl shadow-sm">
          <BookOpen className="h-16 w-16 mx-auto text-gray-300 dark:text-gray-600 mb-4" />
          <h3 className="text-xl font-medium text-gray-900 dark:text-white mb-2">No resources found</h3>
          <p className="text-gray-500 dark:text-gray-400 mb-6 max-w-md mx-auto">
            Try adjusting your search or filter to find what you're looking for.
          </p>
          <Button onClick={() => { setSearchTerm(''); setSelectedCategory('All'); }}>
            Clear Filters
          </Button>
        </div>
      )}
    </div>
  );
};

interface ResourceCardProps {
  resource: Resource;
  index: number;
  getCategoryIcon: (category: string) => JSX.Element;
}

const ResourceCard = ({ resource, index, getCategoryIcon }: ResourceCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.05 }}
    >
      <Card className="h-full flex flex-col overflow-hidden">
        <div className="h-48 overflow-hidden">
          <img 
            src={resource.image} 
            alt={resource.title} 
            className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
          />
        </div>
        <CardHeader>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center">
              {getCategoryIcon(resource.category)}
              <span className="ml-2 text-sm text-gray-500 dark:text-gray-400">{resource.category}</span>
            </div>
          </div>
          <CardTitle>{resource.title}</CardTitle>
          <CardDescription>{resource.description}</CardDescription>
        </CardHeader>
        <CardContent className="flex-grow">
          <div className="flex flex-wrap gap-2 mb-6">
            {resource.tags.map((tag) => (
              <span 
                key={tag} 
                className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded text-xs"
              >
                {tag}
              </span>
            ))}
          </div>
          
          <a 
            href={resource.url} 
            target="_blank" 
            rel="noopener noreferrer" 
            className="inline-flex items-center text-indigo-600 dark:text-indigo-400 font-medium text-sm hover:underline"
          >
            Visit Resource
            <ExternalLink size={14} className="ml-1" />
          </a>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default Resources;